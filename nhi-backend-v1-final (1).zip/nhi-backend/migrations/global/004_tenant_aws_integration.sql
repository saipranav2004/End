-- Apply once to the GLOBAL database, after 001. Safe to run again.
--
-- AWS connection for each tenant ("Integrations" page).
--
--   nhi_global.tenants              + domain, aws_account_id, external_id, event_bus_arn
--                                     Filled by the super-admin onboarding page.
--   nhi_global.tenant_aws_accounts  one row per connected customer AWS account
--                                     (account number, enabled regions, role ARN,
--                                     External ID, check results, sync state)
--
-- Both live in the global database: an External ID must be unique across all
-- tenants, and one AWS account may belong to one tenant only - the event
-- pipeline maps an event's account to a tenant, so a shared account would leak
-- one tenant's events into another.
--
-- Upgrading from the earlier integration build: values in
-- aws_platform_settings and tenant_aws_integrations are copied into tenants,
-- and those two tables are renamed *_migrated (not dropped). Drop them once
-- you have checked the copy.
BEGIN;

-- ── tenants ────────────────────────────────────────────────────────────────
ALTER TABLE nhi_global.tenants ADD COLUMN IF NOT EXISTS domain         text;
ALTER TABLE nhi_global.tenants ADD COLUMN IF NOT EXISTS aws_account_id text;  -- our AWS account the customer trusts
ALTER TABLE nhi_global.tenants ADD COLUMN IF NOT EXISTS event_bus_arn  text;  -- our central bus the customer forwards to
-- Generated per row (existing tenants get one too). The super-admin page may
-- set its own; it must stay unique and should never change once a customer
-- role trusts it.
ALTER TABLE nhi_global.tenants ADD COLUMN IF NOT EXISTS external_id text
    DEFAULT ('ext-' || replace(gen_random_uuid()::text, '-', ''));

DO $$
BEGIN
    -- Carry over values from the earlier build, then retire its tables so a
    -- re-run never overwrites what the super admin has set since.
    IF to_regclass('nhi_global.tenant_aws_integrations') IS NOT NULL THEN
        UPDATE nhi_global.tenants t
           SET external_id = i.external_id
          FROM nhi_global.tenant_aws_integrations i
         WHERE i.tenant_id = t.tenant_id;
        ALTER TABLE nhi_global.tenant_aws_integrations RENAME TO tenant_aws_integrations_migrated;
    END IF;
    IF to_regclass('nhi_global.aws_platform_settings') IS NOT NULL THEN
        UPDATE nhi_global.tenants t
           SET aws_account_id = COALESCE(t.aws_account_id, p.account_id),
               event_bus_arn  = COALESCE(t.event_bus_arn,  p.event_bus_arn)
          FROM nhi_global.aws_platform_settings p
         WHERE p.id = 1;
        ALTER TABLE nhi_global.aws_platform_settings RENAME TO aws_platform_settings_migrated;
    END IF;
END $$;

UPDATE nhi_global.tenants
   SET external_id = 'ext-' || replace(gen_random_uuid()::text, '-', '')
 WHERE external_id IS NULL;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenants_domain_format') THEN
        -- Stored lowercase, without "@": acme.com
        ALTER TABLE nhi_global.tenants ADD CONSTRAINT tenants_domain_format
            CHECK (domain IS NULL OR domain ~ '^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenants_aws_account_id_format') THEN
        ALTER TABLE nhi_global.tenants ADD CONSTRAINT tenants_aws_account_id_format
            CHECK (aws_account_id IS NULL OR aws_account_id ~ '^[0-9]{12}$');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenants_event_bus_arn_format') THEN
        -- The API also checks the bus is in aws_account_id.
        ALTER TABLE nhi_global.tenants ADD CONSTRAINT tenants_event_bus_arn_format
            CHECK (event_bus_arn IS NULL OR (length(event_bus_arn) <= 320
                AND event_bus_arn ~ '^arn:aws:events:[a-z]{2}(-[a-z]+)+-[0-9]{1,2}:[0-9]{12}:event-bus/[A-Za-z0-9._-]+$'));
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenants_external_id_format') THEN
        -- AWS's External ID alphabet, at least 16 characters: short, guessable
        -- values defeat its purpose.
        ALTER TABLE nhi_global.tenants ADD CONSTRAINT tenants_external_id_format
            CHECK (external_id IS NULL OR (length(external_id) BETWEEN 16 AND 1224
                AND external_id ~ '^[A-Za-z0-9+=,.@:/_-]+$'));
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_tenants_domain      ON nhi_global.tenants (lower(domain));
CREATE UNIQUE INDEX IF NOT EXISTS uq_tenants_external_id ON nhi_global.tenants (external_id);

-- ── connected customer accounts ────────────────────────────────────────────
-- A row is written only after the API has assumed the role with the tenant's
-- External ID, which proves the tenant controls the account.
CREATE TABLE IF NOT EXISTS nhi_global.tenant_aws_accounts (
    tenant_id         uuid NOT NULL REFERENCES nhi_global.tenants (tenant_id) ON DELETE CASCADE,
    aws_account_id    text NOT NULL CHECK (aws_account_id ~ '^[0-9]{12}$'),
    role_arn          text NOT NULL,
    status            text NOT NULL CHECK (status IN ('connected', 'action_needed')),
    checks            jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(checks) = 'array'),
    last_verified_at  timestamptz NOT NULL DEFAULT now(),
    last_verified_by  text NOT NULL DEFAULT '',
    connected_at      timestamptz,
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, aws_account_id)
);

-- Regions the customer allows us to read; a sync covers exactly these.
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS regions text[] NOT NULL DEFAULT '{}';
-- The External ID the role was verified with (the tenant's, at that time).
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS external_id text;

-- Sync state. The API sets 'queued'; the discovery worker claims a row
-- (queued -> running), then sets succeeded or failed:
--   UPDATE ... SET sync_status = 'running', sync_started_at = now()
--    WHERE (tenant_id, aws_account_id) = (
--          SELECT tenant_id, aws_account_id FROM nhi_global.tenant_aws_accounts
--           WHERE sync_status = 'queued' ORDER BY sync_requested_at
--           FOR UPDATE SKIP LOCKED LIMIT 1)
--   RETURNING tenant_id, aws_account_id, role_arn, external_id, regions;
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS sync_status       text NOT NULL DEFAULT 'idle';
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS sync_requested_at timestamptz;
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS sync_requested_by text NOT NULL DEFAULT '';
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS sync_started_at   timestamptz;
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS last_synced_at    timestamptz;
ALTER TABLE nhi_global.tenant_aws_accounts ADD COLUMN IF NOT EXISTS last_sync_error   text NOT NULL DEFAULT '';

UPDATE nhi_global.tenant_aws_accounts a
   SET external_id = t.external_id
  FROM nhi_global.tenants t
 WHERE t.tenant_id = a.tenant_id AND a.external_id IS NULL;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenant_aws_accounts_sync_status') THEN
        ALTER TABLE nhi_global.tenant_aws_accounts ADD CONSTRAINT tenant_aws_accounts_sync_status
            CHECK (sync_status IN ('idle', 'queued', 'running', 'succeeded', 'failed'));
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tenant_aws_accounts_regions_format') THEN
        ALTER TABLE nhi_global.tenant_aws_accounts ADD CONSTRAINT tenant_aws_accounts_regions_format
            CHECK (array_position(regions, NULL) IS NULL AND cardinality(regions) <= 64);
    END IF;
END $$;

-- An AWS account belongs to one tenant only.
CREATE UNIQUE INDEX IF NOT EXISTS uq_tenant_aws_accounts_account
    ON nhi_global.tenant_aws_accounts (aws_account_id);
-- The worker's queue.
CREATE INDEX IF NOT EXISTS idx_tenant_aws_accounts_sync_queue
    ON nhi_global.tenant_aws_accounts (sync_requested_at)
    WHERE sync_status = 'queued';

COMMIT;

package eventstore

import (
	"context"
	"testing"
	"time"
)

// The "events received" check of the AWS connection: an account that never
// sent any events has none, and nothing is newer than the future.
func TestIntegrationAccountHasEventsSince(t *testing.T) {
	c := integrationClient(t)
	ctx := context.Background()
	if found, err := c.AccountHasEventsSince(ctx, "000000000000", time.Now().AddDate(-5, 0, 0)); err != nil || found {
		t.Fatalf("unknown account = %v, %v; want false", found, err)
	}
	if found, err := c.AccountHasEventsSince(ctx, devAccount, time.Now().Add(time.Hour)); err != nil || found {
		t.Fatalf("future window = %v, %v; want false", found, err)
	}
}

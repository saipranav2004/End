package identitygraph

import (
	"context"
	"time"

	chrepo "nhi-backend-api/internal/identitygraph/eventstore"
)

// TestNow is the fixed "now" used by the activity unit tests.
var TestNow = time.Date(2026, 10, 13, 12, 0, 0, 0, time.UTC)

// FakeActivity is an in-memory ActivitySource for unit tests (this package's
// and the feature modules').
type FakeActivity struct {
	Up        bool
	Impaired  bool
	Seen      map[string]time.Time
	CreatorOf map[string]string
	Used      map[string][]chrepo.UsedAction
	Perms     []chrepo.UsedPermission
	Edges     []chrepo.AccessEdge
	Changes   map[string][]chrepo.ChangeEvent

	SeenCalls int
	LastSince time.Time // the "since" the most recent windowed call used
}

func (f *FakeActivity) Available() bool { return f.Up }
func (f *FakeActivity) Degraded() bool  { return f.Impaired }
func (f *FakeActivity) LastSeen(_ context.Context, keys []string) map[string]time.Time {
	f.SeenCalls++
	out := map[string]time.Time{}
	for _, k := range keys {
		if t, ok := f.Seen[k]; ok {
			out[k] = t
		}
	}
	return out
}
func (f *FakeActivity) Creators(_ context.Context, arns []string) map[string]string {
	out := map[string]string{}
	for _, a := range arns {
		if c, ok := f.CreatorOf[a]; ok {
			out[a] = c
		}
	}
	return out
}
func (f *FakeActivity) UsedActionSets(_ context.Context, keys []string, since time.Time) map[string][]chrepo.UsedAction {
	f.LastSince = since
	out := map[string][]chrepo.UsedAction{}
	for _, k := range keys {
		if u, ok := f.Used[k]; ok {
			out[k] = u
		}
	}
	return out
}
func (f *FakeActivity) UsedPermissions(_ context.Context, _ []string, since time.Time) []chrepo.UsedPermission {
	f.LastSince = since
	return f.Perms
}
func (f *FakeActivity) AccessEdges(_ context.Context, _ []string, since time.Time) []chrepo.AccessEdge {
	f.LastSince = since
	return f.Edges
}

func (f *FakeActivity) ChangeEvents(_ context.Context, arn string) []chrepo.ChangeEvent {
	return f.Changes[arn]
}

var _ ActivitySource = (*FakeActivity)(nil)

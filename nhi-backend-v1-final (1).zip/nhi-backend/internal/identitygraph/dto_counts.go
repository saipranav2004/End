package identitygraph

// Count-by-dimension items shared by the filters and dashboard responses.

type RegionFilter struct {
	Region string `json:"region"`
	Count  int    `json:"count"`
}

type TypeCountFilter struct {
	Type  string `json:"type"`
	Count int    `json:"count"`
}

type ClassCountFilter struct {
	Class string `json:"class"`
	Count int    `json:"count"`
}

type EnvironmentCountFilter struct {
	Environment string `json:"environment"`
	Count       int    `json:"count"`
}

type StatusCountFilter struct {
	Status string `json:"status"`
	Count  int    `json:"count"`
}

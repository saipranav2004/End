// Package scanchanges locates a tenant's latest finished AWS scan. It is the
// one place that knows how "latest scan" is spelled on nhi_scans_aws, so the
// dashboard and the scan-changes features share the semantics without touching
// scope.Resolver (which every endpoint depends on).
package scanchanges

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/lib/pq"

	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// ScanMeta describes the newest finished scan in the caller's scope.
type ScanMeta struct {
	ScanID    string
	ScannedAt *time.Time
}

// LatestCompletedScan returns the newest finished scan for the caller's
// selected accounts: status COMPLETED or PARTIAL (matched case-insensitively —
// tenants have stored both 'COMPLETED' and 'completed'), newest scan_end
// first, NULLs last.
//
// found is false when there is no such scan, and a table the tenant has not
// been provisioned for yet is also "not found": neither is an error, so a
// missing scan_changes/nhi_scans_aws can never fail a caller.
func LatestCompletedScan(ctx context.Context, sc *scope.DataScope) (ScanMeta, bool, error) {
	if sc == nil || sc.DB == nil {
		return ScanMeta{}, false, nil
	}
	query := fmt.Sprintf(`
		SELECT scan_id::text, scan_end
		FROM %s
		WHERE upper(status) IN ('COMPLETED', 'PARTIAL')
		  AND account_id = ANY($1::text[])
		ORDER BY scan_end DESC NULLS LAST
		LIMIT 1`, sc.Table("nhi_scans_aws"))

	var meta ScanMeta
	err := sc.DB.QueryRowContext(ctx, query, pq.Array(sc.AccountIDs)).Scan(&meta.ScanID, &meta.ScannedAt)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) || database.IsUndefinedTable(err) {
			return ScanMeta{}, false, nil
		}
		return ScanMeta{}, false, fmt.Errorf("latest completed scan: %w", err)
	}
	if meta.ScanID == "" {
		return ScanMeta{}, false, nil
	}
	return meta, true, nil
}

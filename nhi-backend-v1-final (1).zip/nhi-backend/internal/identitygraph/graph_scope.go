package identitygraph

import (
	"context"
	"errors"
	"strings"

	"nhi-backend-api/internal/platform/scope"
)

// ErrScopeRequired is the single sentinel returned by every scoped repository
// entry point when it is handed a nil or unopened DataScope. Callers can test
// for it with errors.Is instead of comparing message strings.
var ErrScopeRequired = errors.New("tenant scope is required")

// ═══════════════════════════════════════════════════════════════════════════
// Tenant scope enforcement for the relationship graph (tab=relationships).
//
// Every other tab reads rows through DataScope.Predicates(), so the PostgreSQL
// predicate itself keeps them inside the caller's account/region selection. A
// graph traversal cannot do that: it walks trust_edges hop by hop, and hop 2
// can leave the selected accounts entirely.
//
// The rule here is therefore enforced in Go, before an edge is ever added to
// the frontier:
//
//	an edge is traversable only when BOTH endpoints resolve to an ARN whose
//	account (and, when the ARN carries one, whose region) is inside the
//	caller's resolved scope.
//
// Because the frontier only ever grows through scoped nodes, the traversal can
// never escape the tenant's selection — the graph is pruned at the boundary,
// not filtered after the fact.
//
// This fails closed: an ARN whose account id cannot be parsed is not traversable.
// ═══════════════════════════════════════════════════════════════════════════

// arnAccount extracts the AWS account id from an ARN.
//
//	arn:aws:iam::123456789012:role/app-role
//	      0   1  2 3          4
//
// Returns "" when the ARN is not well formed enough to yield an account id
// (for example arn:aws:iam::aws:policy/ReadOnly, which has none).
func arnAccount(arn string) string {
	parts := strings.Split(strings.TrimSpace(arn), ":")
	if len(parts) < 5 {
		return ""
	}
	return parts[4]
}

// arnRegion extracts the region from an ARN. Global services (IAM, S3,
// CloudFront) legitimately carry an empty region, in which case "" is returned
// and the region part of the scope check is skipped.
func arnRegion(arn string) string {
	parts := strings.Split(strings.TrimSpace(arn), ":")
	if len(parts) < 4 {
		return ""
	}
	return parts[3]
}

// scopeAllowsARN reports whether arn may appear in a relationship graph built
// for the given resolved scope.
func scopeAllowsARN(s *scope.DataScope, arn string) bool {
	if s == nil {
		return false
	}
	// An empty account selection means "nothing is in scope" — this mirrors
	// DataScope.Predicates(), where account_id = ANY('{}') matches no rows.
	if len(s.AccountIDs) == 0 {
		return false
	}

	account := arnAccount(arn)
	if account == "" {
		return false
	}
	if !containsString(s.AccountIDs, account) {
		return false
	}

	// Region is only enforced when the ARN actually carries one.
	if region := arnRegion(arn); region != "" && len(s.Regions) > 0 {
		if !containsString(s.Regions, region) {
			return false
		}
	}
	return true
}

// scopeAllowsEdge reports whether a trust edge may be traversed. Both endpoints
// must be in scope; an edge that leaves the selection is dropped entirely.
func scopeAllowsEdge(s *scope.DataScope, source, target string) bool {
	return scopeAllowsARN(s, source) && scopeAllowsARN(s, target)
}

// traverseGraph walks trust_edges outward from rootARN, pruning at the tenant
// scope boundary on every hop.
//
// It returns the edges that survived scope filtering plus every ARN reached
// (root first, then in discovery order) so callers can resolve node metadata.
//
// The traversal is bounded three ways: by depth (1–5), by the caller's
// account/region scope, and by the visited set (an edge is emitted at most
// once, so a cyclic trust graph cannot loop forever).
func (r *CredentialDetailRepository) traverseGraph(
	ctx context.Context,
	resolved *scope.DataScope,
	rootARN string,
	depth int,
	edgeTypes []string,
) ([]graphEdgeRow, []string, error) {
	if resolved == nil || resolved.DB == nil {
		return nil, nil, ErrScopeRequired
	}
	if depth < 1 {
		depth = 1
	}
	if depth > 5 {
		depth = 5
	}

	visited := map[string]bool{rootARN: true}
	order := []string{rootARN}
	frontier := []string{rootARN}
	var allEdges []graphEdgeRow

	// loadEdgesTouching matches source_arn = ANY(frontier) OR target_arn =
	// ANY(frontier), so an edge is returned again on every hop that touches
	// either endpoint. Without de-duplication a 2-hop walk reports the same
	// edge twice, which double-counts it in the graph and in the relationship
	// table.
	seen := map[graphEdgeKey]bool{}

	for hop := 0; hop < depth && len(frontier) > 0; hop++ {
		edges, err := r.loadEdgesTouching(ctx, resolved.DB, resolved.QSchema(), frontier, edgeTypes)
		if err != nil {
			return nil, nil, err
		}
		kept, next := scopedEdges(resolved, edges, visited)
		for _, e := range kept {
			key := graphEdgeKey{Source: e.Source, Target: e.Target, EdgeType: e.EdgeType}
			if seen[key] {
				continue
			}
			seen[key] = true
			allEdges = append(allEdges, e)
		}
		order = append(order, next...)
		frontier = next
	}
	return allEdges, order, nil
}

// graphEdgeKey identifies an edge for de-duplication.
type graphEdgeKey struct {
	Source   string
	Target   string
	EdgeType string
}

// scopedEdges keeps only the traversable edges and returns the not-yet-visited
// endpoints as the next BFS frontier.
func scopedEdges(s *scope.DataScope, edges []graphEdgeRow, visited map[string]bool) (kept []graphEdgeRow, frontier []string) {
	kept = make([]graphEdgeRow, 0, len(edges))
	for _, e := range edges {
		if !scopeAllowsEdge(s, e.Source, e.Target) {
			continue
		}
		kept = append(kept, e)
		for _, arn := range [...]string{e.Source, e.Target} {
			if !visited[arn] {
				visited[arn] = true
				frontier = append(frontier, arn)
			}
		}
	}
	return kept, frontier
}

func containsString(haystack []string, needle string) bool {
	for _, v := range haystack {
		if v == needle {
			return true
		}
	}
	return false
}

// parseEdgeTypes splits the comma-separated ?edge_type= filter. An empty or
// absent value means "every edge type".
func parseEdgeTypes(edgeType string) []string {
	var out []string
	for _, et := range strings.Split(edgeType, ",") {
		if et = strings.TrimSpace(et); et != "" {
			out = append(out, et)
		}
	}
	return out
}

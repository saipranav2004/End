package permissionsource

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/lib/pq"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

// PermissionSourceRepository answers "which policy granted this event" from a
// credential's effective_permissions document.
type PermissionSourceRepository struct{}

func NewPermissionSourceRepository() *PermissionSourceRepository {
	return &PermissionSourceRepository{}
}

// Find looks up the grant that covers an event (service short name such as
// "s3", and the CloudTrail event name such as "GetObject") for one credential.
// The credential must be inside the caller's accounts and regions;
// otherwise ErrCredentialNotFound is returned. A credential with no matching
// grant is a normal answer (Matched=false), not an error.
func (r *PermissionSourceRepository) Find(ctx context.Context, resolved *scope.DataScope, credentialID, service, eventName string) (*identitygraph.PermissionSourceResponse, error) {
	if resolved == nil || resolved.DB == nil {
		return nil, identitygraph.ErrCredentialNotFound
	}
	query := fmt.Sprintf(`
		SELECT ep.permissions
		FROM %[1]s.credentials c
		LEFT JOIN %[1]s.effective_permissions ep ON ep.credential_id::text = c.id::text
		WHERE c.id = $1::uuid
		  AND c.account_id = ANY($2::text[]) AND c.region = ANY($3::text[])
		  AND c.deleted_at IS NULL
		LIMIT 1`, resolved.QSchema())

	var raw []byte
	err := resolved.DB.QueryRowContext(ctx, query, credentialID,
		pq.Array(resolved.AccountIDs), pq.Array(resolved.Regions)).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, identitygraph.ErrCredentialNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("load effective permissions: %w", err)
	}

	var entries []map[string]interface{}
	if len(raw) > 0 {
		_ = json.Unmarshal(raw, &entries)
	}
	return identitygraph.GrantResponse(identitygraph.BestGrant(entries, service, eventName)), nil
}

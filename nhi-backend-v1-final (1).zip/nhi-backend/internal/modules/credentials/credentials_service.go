package credentials

import (
	"context"
	"fmt"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

type CredentialsService struct {
	repo     *CredentialsRepository
	resolver *scope.Resolver
	activity *identitygraph.ActivityService
}

func NewCredentialsService(repo *CredentialsRepository, resolver *scope.Resolver, activity *identitygraph.ActivityService) *CredentialsService {
	return &CredentialsService{repo: repo, resolver: resolver, activity: activity}
}

func (s *CredentialsService) GetCredentials(ctx context.Context, userID, tenantID, dbName string, f CredentialListFilter) (*CredentialListResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}
	result, err := s.repo.GetCredentialsList(ctx, resolved, f, s.activity.ForRequest(resolved))
	if err != nil {
		return nil, fmt.Errorf("get scoped credentials: %w", err)
	}
	return result, nil
}

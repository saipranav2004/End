package awsintegration

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
	"github.com/lib/pq"

	"nhi-backend-api/internal/platform/database"
)

const (
	awsAccountsTable    = "tenant_aws_accounts"
	awsAccountUniqueIdx = "uq_tenant_aws_accounts_account"
)

var (
	// ErrAWSAccountClaimed: the AWS account is already connected to another tenant.
	ErrAWSAccountClaimed = errors.New("aws account is connected to another tenant")
	// ErrAWSAccountNotFound: the tenant has no such account.
	ErrAWSAccountNotFound = errors.New("aws account not found")
	// ErrAWSAccountNotConnected: the account has not passed all checks.
	ErrAWSAccountNotConnected = errors.New("aws account is not connected")
	// ErrAWSTablesMissing: migrations/global/002_tenant_aws_integration.sql
	// has not been applied to the global database.
	ErrAWSTablesMissing = errors.New("aws integration schema is missing: apply migrations/global/002_tenant_aws_integration.sql to the global database")
)

// missingSchema maps undefined_table (42P01) and undefined_column (42703) to
// ErrAWSTablesMissing, so a deployment that skipped the migration says so.
func missingSchema(err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && (pgErr.Code == "42P01" || pgErr.Code == "42703") {
		return fmt.Errorf("%w (%s)", ErrAWSTablesMissing, pgErr.Message)
	}
	return err
}

// AWSIntegrationRepository reads the tenant's AWS values from
// nhi_global.tenants and keeps nhi_global.tenant_aws_accounts. Both are in the
// global database, so every query is keyed by the tenant_id from the token.
type AWSIntegrationRepository struct {
	db     *database.PostgresDB
	schema string
}

func NewAWSIntegrationRepository(db *database.PostgresDB) *AWSIntegrationRepository {
	schema := "nhi_global"
	if db != nil && strings.TrimSpace(db.GlobalSchema()) != "" {
		schema = db.GlobalSchema()
	}
	return &AWSIntegrationRepository{db: db, schema: schema}
}

func (r *AWSIntegrationRepository) globalDB() (*sql.DB, error) {
	if r == nil || r.db == nil || r.db.DB == nil {
		return nil, errors.New("aws integration repository is not initialized")
	}
	return r.db.DB, nil
}

// TenantSettings returns the tenant's AWS values, or nil when the tenant does
// not exist. Unset columns come back empty.
func (r *AWSIntegrationRepository) TenantSettings(ctx context.Context, tenantID string) (*AWSTenantSettings, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `SELECT COALESCE(domain, ''), COALESCE(aws_account_id, ''), COALESCE(external_id, ''), COALESCE(event_bus_arn, '')
		FROM ` + database.Table(r.schema, "tenants") + ` WHERE tenant_id = $1::uuid`
	var s AWSTenantSettings
	err = db.QueryRowContext(ctx, q, tenantID).Scan(&s.Domain, &s.AWSAccountID, &s.ExternalID, &s.EventBusARN)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("load tenant aws settings: %w", missingSchema(err))
	}
	return &s, nil
}

const accountColumns = `tenant_id::text, aws_account_id, role_arn, regions, COALESCE(external_id, ''), status, checks,
	last_verified_at, last_verified_by, connected_at, sync_status, sync_requested_at, sync_requested_by,
	sync_started_at, last_synced_at, last_sync_error`

type rowScanner interface{ Scan(dest ...any) error }

func scanAccount(row rowScanner) (*AWSAccountRecord, error) {
	var rec AWSAccountRecord
	var regions pq.StringArray
	var checks []byte
	var connectedAt, requestedAt, startedAt, syncedAt sql.NullTime
	if err := row.Scan(&rec.TenantID, &rec.AccountID, &rec.RoleARN, &regions, &rec.ExternalID, &rec.Status, &checks,
		&rec.LastVerifiedAt, &rec.LastVerifiedBy, &connectedAt, &rec.SyncStatus, &requestedAt, &rec.SyncRequestedBy,
		&startedAt, &syncedAt, &rec.LastSyncError); err != nil {
		return nil, err
	}
	rec.Regions = []string(regions)
	if rec.Regions == nil {
		rec.Regions = []string{}
	}
	rec.Checks = make([]AWSCheck, 0)
	if len(checks) > 0 {
		if err := json.Unmarshal(checks, &rec.Checks); err != nil {
			return nil, fmt.Errorf("decode aws account checks: %w", err)
		}
	}
	rec.LastVerifiedAt = rec.LastVerifiedAt.UTC()
	rec.ConnectedAt = utcPtr(connectedAt)
	rec.SyncRequestedAt = utcPtr(requestedAt)
	rec.SyncStartedAt = utcPtr(startedAt)
	rec.LastSyncedAt = utcPtr(syncedAt)
	return &rec, nil
}

func utcPtr(t sql.NullTime) *time.Time {
	if !t.Valid {
		return nil
	}
	v := t.Time.UTC()
	return &v
}

// ListAccounts returns the tenant's AWS accounts, connected first.
func (r *AWSIntegrationRepository) ListAccounts(ctx context.Context, tenantID string) ([]AWSAccountRecord, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `SELECT ` + accountColumns + ` FROM ` + database.Table(r.schema, awsAccountsTable) + `
		WHERE tenant_id = $1::uuid
		ORDER BY (status = 'connected') DESC, created_at, aws_account_id`
	rows, err := db.QueryContext(ctx, q, tenantID)
	if err != nil {
		return nil, fmt.Errorf("list aws accounts: %w", missingSchema(err))
	}
	defer rows.Close()
	out := make([]AWSAccountRecord, 0)
	for rows.Next() {
		rec, err := scanAccount(rows)
		if err != nil {
			return nil, fmt.Errorf("scan aws account: %w", err)
		}
		out = append(out, *rec)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate aws accounts: %w", err)
	}
	return out, nil
}

// GetAccount returns one of the tenant's accounts, or nil.
func (r *AWSIntegrationRepository) GetAccount(ctx context.Context, tenantID, accountID string) (*AWSAccountRecord, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `SELECT ` + accountColumns + ` FROM ` + database.Table(r.schema, awsAccountsTable) + `
		WHERE tenant_id = $1::uuid AND aws_account_id = $2`
	rec, err := scanAccount(db.QueryRowContext(ctx, q, tenantID, accountID))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("load aws account: %w", missingSchema(err))
	}
	return rec, nil
}

// AccountClaimedByOther reports whether the AWS account is connected to a
// tenant other than tenantID.
func (r *AWSIntegrationRepository) AccountClaimedByOther(ctx context.Context, tenantID, accountID string) (bool, error) {
	db, err := r.globalDB()
	if err != nil {
		return false, err
	}
	var claimed bool
	q := `SELECT EXISTS (SELECT 1 FROM ` + database.Table(r.schema, awsAccountsTable) + `
		WHERE aws_account_id = $1 AND tenant_id <> $2::uuid)`
	if err := db.QueryRowContext(ctx, q, accountID, tenantID).Scan(&claimed); err != nil {
		return false, fmt.Errorf("check aws account owner: %w", missingSchema(err))
	}
	return claimed, nil
}

// SaveVerification records the outcome of a verification: role, regions,
// External ID, status and checks. connected_at is set the first time the
// account passes and kept afterwards. That first time, a sync is queued (so
// data starts arriving without anyone pressing Sync); syncQueued reports it.
func (r *AWSIntegrationRepository) SaveVerification(ctx context.Context, rec AWSAccountRecord) (saved *AWSAccountRecord, syncQueued bool, err error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, false, err
	}
	checks, err := json.Marshal(rec.Checks)
	if err != nil {
		return nil, false, fmt.Errorf("encode aws account checks: %w", err)
	}
	table := database.Table(r.schema, awsAccountsTable)

	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return nil, false, fmt.Errorf("begin: %w", err)
	}
	defer func() { _ = tx.Rollback() }()

	var prevConnected sql.NullTime
	var prevSync string
	err = tx.QueryRowContext(ctx, `SELECT connected_at, sync_status FROM `+table+`
		WHERE tenant_id = $1::uuid AND aws_account_id = $2 FOR UPDATE`, rec.TenantID, rec.AccountID).Scan(&prevConnected, &prevSync)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return nil, false, fmt.Errorf("lock aws account: %w", missingSchema(err))
	}
	queue := rec.Status == AWSStatusConnected && !prevConnected.Valid &&
		prevSync != AWSSyncQueued && prevSync != AWSSyncRunning

	q := `INSERT INTO ` + table + ` AS a
			(tenant_id, aws_account_id, role_arn, regions, external_id, status, checks,
			 last_verified_at, last_verified_by, connected_at,
			 sync_status, sync_requested_at, sync_requested_by, updated_at)
		VALUES ($1::uuid, $2, $3, $4::text[], $5, $6, $7::jsonb, $8, $9,
			CASE WHEN $6 = 'connected' THEN $8::timestamptz END,
			CASE WHEN $10 THEN 'queued' ELSE 'idle' END,
			CASE WHEN $10 THEN $8::timestamptz END,
			CASE WHEN $10 THEN $9 ELSE '' END,
			now())
		ON CONFLICT (tenant_id, aws_account_id) DO UPDATE SET
			role_arn = EXCLUDED.role_arn,
			regions = EXCLUDED.regions,
			external_id = EXCLUDED.external_id,
			status = EXCLUDED.status,
			checks = EXCLUDED.checks,
			last_verified_at = EXCLUDED.last_verified_at,
			last_verified_by = EXCLUDED.last_verified_by,
			connected_at = COALESCE(a.connected_at, EXCLUDED.connected_at),
			sync_status = CASE WHEN $10 THEN 'queued' ELSE a.sync_status END,
			sync_requested_at = CASE WHEN $10 THEN EXCLUDED.sync_requested_at ELSE a.sync_requested_at END,
			sync_requested_by = CASE WHEN $10 THEN EXCLUDED.sync_requested_by ELSE a.sync_requested_by END,
			last_sync_error = CASE WHEN $10 THEN '' ELSE a.last_sync_error END,
			updated_at = now()
		RETURNING ` + accountColumns
	saved, err = scanAccount(tx.QueryRowContext(ctx, q, rec.TenantID, rec.AccountID, rec.RoleARN, pq.Array(rec.Regions),
		rec.ExternalID, rec.Status, checks, rec.LastVerifiedAt, rec.LastVerifiedBy, queue))
	if err != nil {
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == "23505" && pgErr.ConstraintName == awsAccountUniqueIdx {
			return nil, false, ErrAWSAccountClaimed
		}
		return nil, false, fmt.Errorf("save aws account: %w", missingSchema(err))
	}
	if err := tx.Commit(); err != nil {
		return nil, false, fmt.Errorf("commit aws account: %w", err)
	}
	return saved, queue, nil
}

// UpdateRegions replaces the regions an account is read in.
func (r *AWSIntegrationRepository) UpdateRegions(ctx context.Context, tenantID, accountID string, regions []string) (*AWSAccountRecord, error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, err
	}
	q := `UPDATE ` + database.Table(r.schema, awsAccountsTable) + `
		SET regions = $3::text[], updated_at = now()
		WHERE tenant_id = $1::uuid AND aws_account_id = $2
		RETURNING ` + accountColumns
	rec, err := scanAccount(db.QueryRowContext(ctx, q, tenantID, accountID, pq.Array(regions)))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrAWSAccountNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("update aws account regions: %w", missingSchema(err))
	}
	return rec, nil
}

// RequestSync queues a sync of a connected account. When one is already
// queued or running it changes nothing and reports alreadyQueued.
func (r *AWSIntegrationRepository) RequestSync(ctx context.Context, tenantID, accountID, actor string, at time.Time) (rec *AWSAccountRecord, alreadyQueued bool, err error) {
	db, err := r.globalDB()
	if err != nil {
		return nil, false, err
	}
	q := `UPDATE ` + database.Table(r.schema, awsAccountsTable) + `
		SET sync_status = 'queued', sync_requested_at = $3, sync_requested_by = $4,
			last_sync_error = '', updated_at = now()
		WHERE tenant_id = $1::uuid AND aws_account_id = $2
		  AND status = 'connected' AND sync_status NOT IN ('queued', 'running')
		RETURNING ` + accountColumns
	rec, err = scanAccount(db.QueryRowContext(ctx, q, tenantID, accountID, at, actor))
	if err == nil {
		return rec, false, nil
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return nil, false, fmt.Errorf("queue aws sync: %w", missingSchema(err))
	}
	// Nothing updated: say why.
	current, err := r.GetAccount(ctx, tenantID, accountID)
	if err != nil {
		return nil, false, err
	}
	switch {
	case current == nil:
		return nil, false, ErrAWSAccountNotFound
	case current.Status != AWSStatusConnected:
		return current, false, ErrAWSAccountNotConnected
	default:
		return current, true, nil
	}
}

// DeleteAccount removes one of the tenant's accounts.
func (r *AWSIntegrationRepository) DeleteAccount(ctx context.Context, tenantID, accountID string) error {
	db, err := r.globalDB()
	if err != nil {
		return err
	}
	res, err := db.ExecContext(ctx, `DELETE FROM `+database.Table(r.schema, awsAccountsTable)+`
		WHERE tenant_id = $1::uuid AND aws_account_id = $2`, tenantID, accountID)
	if err != nil {
		return fmt.Errorf("delete aws account: %w", missingSchema(err))
	}
	n, err := res.RowsAffected()
	if err != nil {
		return fmt.Errorf("count deleted aws accounts: %w", err)
	}
	if n == 0 {
		return ErrAWSAccountNotFound
	}
	return nil
}

// ── tenant database ──────────────────────────────────────────────────────

// TenantAccountRegistry keeps the tenant schema's accounts table in
// step with the connected accounts. That table - one row per account and
// region - is the tenant's account list for the whole API: the dashboard's
// default scope, the filters, settings validation and the ClickHouse
// isolation boundary. An account that is connected but not registered there
// would be scanned and then hidden.
type TenantAccountRegistry struct {
	db TenantDBProvider
}

// TenantDBProvider opens a tenant's data database (PostgresDB in production).
type TenantDBProvider interface {
	GetTenantDB(dbName string) (*sql.DB, error)
}

func NewTenantAccountRegistry(db TenantDBProvider) *TenantAccountRegistry {
	return &TenantAccountRegistry{db: db}
}

// Register makes the account's rows match its regions: adds the missing
// regions (as part of the default scope) and removes the ones no longer
// allowed. The synthetic "global" row, written after a scan for IAM and other
// global resources, is left alone.
func (r *TenantAccountRegistry) Register(ctx context.Context, dbName, tenantID, accountID string, regions []string) error {
	if r == nil || r.db == nil {
		return errors.New("tenant account registry is not initialized")
	}
	tenantDB, err := r.db.GetTenantDB(dbName)
	if err != nil {
		return fmt.Errorf("open tenant database: %w", err)
	}
	if regions == nil {
		regions = []string{}
	}
	tx, err := tenantDB.BeginTx(ctx, nil)
	if err != nil {
		return fmt.Errorf("begin: %w", err)
	}
	defer func() { _ = tx.Rollback() }()
	// The accounts table has no unique key, so two registrations of one
	// account at once could each insert the same region. Serialize them.
	if _, err := tx.ExecContext(ctx, `SELECT pg_advisory_xact_lock(hashtext('nhi_aws_account:' || $1 || ':' || $2))`, tenantID, accountID); err != nil {
		return fmt.Errorf("lock account registration: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM `+database.Table(dbName, "accounts")+`
		WHERE tenant_id = $1::uuid AND account_id = $2
		  AND lower(region) <> 'global' AND NOT (region = ANY($3::text[]))`,
		tenantID, accountID, pq.Array(regions)); err != nil {
		return fmt.Errorf("remove deselected regions: %w", err)
	}
	if _, err := tx.ExecContext(ctx, `INSERT INTO `+database.Table(dbName, "accounts")+` (tenant_id, account_id, region, is_default)
		SELECT $1::uuid, $2, wanted.code, true FROM unnest($3::text[]) AS wanted(code)
		WHERE NOT EXISTS (SELECT 1 FROM `+database.Table(dbName, "accounts")+` x
			WHERE x.tenant_id = $1::uuid AND x.account_id = $2 AND x.region = wanted.code)`,
		tenantID, accountID, pq.Array(regions)); err != nil {
		return fmt.Errorf("add regions: %w", err)
	}
	if err := tx.Commit(); err != nil {
		return fmt.Errorf("commit: %w", err)
	}
	return nil
}

// Unregister removes every row of the account, "global" included. Records
// already scanned stay in the tenant database but leave every scope.
func (r *TenantAccountRegistry) Unregister(ctx context.Context, dbName, tenantID, accountID string) error {
	if r == nil || r.db == nil {
		return errors.New("tenant account registry is not initialized")
	}
	tenantDB, err := r.db.GetTenantDB(dbName)
	if err != nil {
		return fmt.Errorf("open tenant database: %w", err)
	}
	if _, err := tenantDB.ExecContext(ctx, `DELETE FROM `+database.Table(dbName, "accounts")+`
		WHERE tenant_id = $1::uuid AND account_id = $2`, tenantID, accountID); err != nil {
		return fmt.Errorf("unregister account: %w", err)
	}
	return nil
}

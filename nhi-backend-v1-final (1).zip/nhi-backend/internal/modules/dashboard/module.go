// Package dashboard serves the dashboard overview API.
package dashboard

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its route.
type Module struct {
	handler *DashboardOverviewHandler
}

// New builds the module.
func New(resolver *scope.Resolver, activity *identitygraph.ActivityService) *Module {
	return &Module{handler: NewDashboardOverviewHandler(NewDashboardOverviewService(NewDashboardOverviewRepository(), resolver, activity))}
}

// Register mounts the dashboard route on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/dashboard/overview", m.handler.Get).Methods(http.MethodGet)
}

package dashboard

import (
	"testing"
	"time"
)

func TestRecentChangeLabelSpecExamplesAndSingulars(t *testing.T) {
	cases := []struct {
		changeType, entityType string
		n                      int
		want                   string
	}{
		// the three wordings given by the spec
		{"CREATED", "identity", 5, "5 new identities discovered"},
		{"DELETED", "credential", 3, "3 credentials removed"},
		{"MODIFIED", "permission", 6, "6 permission changes detected"},
		// singulars
		{"CREATED", "identity", 1, "1 new identity discovered"},
		{"DELETED", "credential", 1, "1 credential removed"},
		{"MODIFIED", "permission", 1, "1 permission change detected"},
		// the rest of the 5 x 3 vocabulary
		{"CREATED", "credential", 2, "2 new credentials discovered"},
		{"DELETED", "identity", 4, "4 identities removed"},
		{"MODIFIED", "identity", 7, "7 identity changes detected"},
		{"CREATED", "permission", 10, "10 new permissions discovered"},
		{"DELETED", "permission", 2, "2 permissions removed"},
		{"CREATED", "binding", 3, "3 new bindings discovered"},
		{"DELETED", "binding", 1, "1 binding removed"},
		{"MODIFIED", "binding", 8, "8 binding changes detected"},
		{"CREATED", "trust_edge", 4, "4 new trust edges discovered"},
		{"DELETED", "trust_edge", 2, "2 trust edges removed"},
		{"MODIFIED", "trust_edge", 5, "5 trust edge changes detected"},
		// unknown vocabulary still renders a label
		{"MODIFIED", "unknown_thing", 1, "1 unknown thing change detected"},
		{"SOMETHING_ELSE", "identity", 2, "2 identity changes detected"},
	}
	for _, c := range cases {
		if got := recentChangeLabel(c.changeType, c.entityType, c.n); got != c.want {
			t.Errorf("label(%s, %s, %d) = %q, want %q", c.changeType, c.entityType, c.n, got, c.want)
		}
	}
}

func TestRecentChangesBlockTotalsAndTopFive(t *testing.T) {
	scanID := "scan-20261016-190603"
	at := time.Date(2026, 10, 16, 13, 37, 0, 0, time.UTC)
	counts := []recentCount{
		{ChangeType: "created", EntityType: "identity", Count: 5},
		{ChangeType: "created", EntityType: "permission", Count: 10},
		{ChangeType: "deleted", EntityType: "credential", Count: 3},
		{ChangeType: "modified", EntityType: "binding", Count: 1},    // smallest, and a tie with trust_edge
		{ChangeType: "modified", EntityType: "trust_edge", Count: 1}, // tie broken by change_type then entity_type
		{ChangeType: "deleted", EntityType: "permission", Count: 10}, // tie with created/permission, sorted by change_type
	}
	prevID := "scan-20261015-190603"
	got := recentChangesBlock(scanID, &prevID, &at, counts)

	// total counts EVERY group, not just the five highlighted
	if got.TotalChanges != 30 {
		t.Errorf("total_changes = %d, want 30", got.TotalChanges)
	}
	if got.LastScanID == nil || *got.LastScanID != scanID {
		t.Errorf("last_scan_id = %v, want %s", got.LastScanID, scanID)
	}
	if got.PreviousScanID == nil || *got.PreviousScanID != prevID {
		t.Errorf("previous_scan_id = %v, want %s", got.PreviousScanID, prevID)
	}
	if got.LastScanTime == nil || !got.LastScanTime.Equal(at) {
		t.Errorf("last_scan_time = %v, want %v", got.LastScanTime, at)
	}
	if len(got.Highlights) != recentChangesTopN {
		t.Fatalf("highlights = %d, want %d", len(got.Highlights), recentChangesTopN)
	}
	wantOrder := []struct {
		changeType, entityType string
		count                  int
	}{
		{"CREATED", "permission", 10},
		{"DELETED", "permission", 10},
		{"CREATED", "identity", 5},
		{"DELETED", "credential", 3},
		{"MODIFIED", "binding", 1}, // tie at 1: "binding" < "trust_edge"
	}
	for i, w := range wantOrder {
		h := got.Highlights[i]
		if h.ChangeType != w.changeType || h.EntityType != w.entityType || h.Count != w.count {
			t.Errorf("highlight[%d] = %+v, want %s/%s/%d", i, h, w.changeType, w.entityType, w.count)
		}
		if h.Label == "" {
			t.Errorf("highlight[%d] has an empty label", i)
		}
	}
}

func TestRecentChangesBlockWithoutScanIsAlwaysPresent(t *testing.T) {
	got := emptyRecentChanges()
	if got.TotalChanges != 0 || got.LastScanID != nil || got.PreviousScanID != nil || got.LastScanTime != nil {
		t.Fatalf("empty block = %+v, want zero/null scan", got)
	}
	if got.Highlights == nil {
		t.Fatal("highlights must be [] , not null")
	}
	// a scan with no change rows still names the scan
	block := recentChangesBlock("scan-x", nil, nil, nil)
	if block.LastScanID == nil || *block.LastScanID != "scan-x" || block.TotalChanges != 0 || len(block.Highlights) != 0 {
		t.Fatalf("no-count block = %+v, want scan id with zero changes", block)
	}
}

package dashboard

import (
	"log"
	"net/http"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/middleware"
)

type DashboardOverviewHandler struct {
	service *DashboardOverviewService
}

func NewDashboardOverviewHandler(service *DashboardOverviewService) *DashboardOverviewHandler {
	return &DashboardOverviewHandler{service: service}
}

// Get handles GET /api/v1/dashboard/overview ("ENDPOINT 3: Dashboard Overview").
// No query parameters — returns all KPIs and all charts in one response.
func (h *DashboardOverviewHandler) Get(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{Success: false, Message: "Unauthorized"})
		return
	}

	if httpx.RejectUnknownQuery(w, r, httpx.NoQuery) {
		return
	}

	result, err := h.service.GetOverview(r.Context(), claims.UserID, claims.TenantID, claims.DBName)
	if err != nil {
		log.Printf("dashboard overview failed: %v", err)
		httpx.WriteJSON(w, http.StatusInternalServerError, httpx.APIResponse{
			Success: false,
			Message: "Failed to retrieve dashboard overview",
			Error:   "DASHBOARD_LOAD_FAILED",
		})
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Dashboard overview retrieved successfully",
		Data:    result,
	})
}

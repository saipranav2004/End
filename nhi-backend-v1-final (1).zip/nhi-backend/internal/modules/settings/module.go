// Package settings serves the per-user dashboard settings API.
package settings

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/platform/database"
	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its routes.
type Module struct {
	handler *SettingsHandler
}

// New builds the module.
func New(pg *database.PostgresDB, resolver *scope.Resolver) *Module {
	return &Module{handler: NewSettingsHandler(NewSettingsService(NewSettingsRepository(), pg, resolver))}
}

// Register mounts the settings routes on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/settings", m.handler.Get).Methods(http.MethodGet)
	r.HandleFunc("/settings", m.handler.Update).Methods(http.MethodPut)
}

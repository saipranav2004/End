// Package identityevents serves the identity events API: the timeline,
// sessions, credentials, IPs, resources, errors, cross-account and heatmap
// sections, and single-event detail.
//
// The shared activity and graph code lives in internal/identitygraph.
package identityevents

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/platform/scope"
)

// Module wires the package's handler and registers its route.
type Module struct {
	handler *IdentityEventsHandler
}

// New builds the module.
func New(resolver *scope.Resolver, activity *identitygraph.ActivityService) *Module {
	return &Module{handler: NewIdentityEventsHandler(NewIdentityEventsService(NewIdentityEventsRepository(), resolver, activity))}
}

// Register mounts the identity events route on an authenticated router.
func (m *Module) Register(r *mux.Router) {
	r.HandleFunc("/identities/{id}/events", m.handler.Get).Methods(http.MethodGet)
}

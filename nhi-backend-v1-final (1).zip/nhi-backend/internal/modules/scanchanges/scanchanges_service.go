package scanchanges

import (
	"context"
	"errors"
	"strings"

	"nhi-backend-api/internal/platform/scope"
)

// ErrScanNotFound: the scan does not exist, or it belongs to an account
// outside the caller's selected scope (never distinguished — a guessed UUID
// must not leak existence).
var ErrScanNotFound = errors.New("scan not found")

type ScanChangesService struct {
	repo     *ScanChangesRepository
	resolver *scope.Resolver
}

func NewScanChangesService(repo *ScanChangesRepository, resolver *scope.Resolver) *ScanChangesService {
	return &ScanChangesService{repo: repo, resolver: resolver}
}

// List resolves the caller's scope, verifies the scan is readable, then
// returns the filter-independent summary plus the filtered page.
func (s *ScanChangesService) List(ctx context.Context, userID, tenantID, dbName string, f ScanChangesFilter) (*ScanChangesResponse, error) {
	resolved, err := s.resolver.Resolve(ctx, userID, tenantID, dbName)
	if err != nil {
		return nil, err
	}

	header, err := s.repo.ScanHeader(ctx, resolved, f.ScanID)
	if err != nil {
		return nil, err // ErrScanNotFound or a real failure
	}

	resp := &ScanChangesResponse{
		ScanID:    header.ScanID,
		Status:    header.Status,
		ScannedAt: header.ScannedAt,
		Summary: ScanChangesSummary{
			ByEntity: map[string]int{},
		},
		Changes: []ScanChangeItem{}, // never null
		Pagination: ScanChangesPagination{
			Page:  f.Page,
			Limit: f.Limit,
		},
	}
	for _, et := range entityTypes {
		resp.Summary.ByEntity[et] = 0
	}

	previous, err := s.repo.PreviousScanID(ctx, resolved, f.ScanID)
	if err != nil {
		return nil, err
	}
	resp.PreviousScanID = previous

	counts, err := s.repo.Counts(ctx, resolved, f.ScanID)
	if err != nil {
		return nil, err
	}
	for _, c := range counts {
		resp.Summary.Total += c.Count
		switch strings.ToUpper(c.ChangeType) {
		case "CREATED":
			resp.Summary.Created += c.Count
		case "DELETED":
			resp.Summary.Deleted += c.Count
		case "MODIFIED":
			resp.Summary.Modified += c.Count
		}
		// Unknown entity types stay out of by_entity, which always carries
		// exactly the five known keys (zero-filled above).
		if et := strings.ToLower(c.EntityType); containsEntityType(et) {
			resp.Summary.ByEntity[et] += c.Count
		}
	}

	items, total, err := s.repo.Page(ctx, resolved, f)
	if err != nil {
		return nil, err
	}
	resp.Changes = items
	resp.Pagination.Total = total

	return resp, nil
}

func containsEntityType(et string) bool {
	for _, known := range entityTypes {
		if known == et {
			return true
		}
	}
	return false
}

package scanchanges

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gorilla/mux"

	jwtpkg "nhi-backend-api/internal/platform/jwt"
	"nhi-backend-api/internal/platform/middleware"
)

// scanRouter serves the handler on the real path. The service is nil: every
// case below must be rejected during validation, before it is touched.
func scanRouter(withClaims bool) http.Handler {
	h := NewScanChangesHandler(nil)
	r := mux.NewRouter()
	r.HandleFunc("/api/v1/scans/{scan_id}/changes", func(w http.ResponseWriter, req *http.Request) {
		if withClaims {
			ctx := context.WithValue(req.Context(), middleware.UserClaimsKey,
				&jwtpkg.CustomClaims{UserID: "u@example.com", TenantID: "11111111-1111-1111-1111-111111111111", DBName: "tenant_a"})
			req = req.WithContext(ctx)
		}
		h.List(w, req)
	}).Methods(http.MethodGet)
	return r
}

func scanGet(h http.Handler, path string) (int, map[string]any) {
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, path, nil))
	var body map[string]any
	_ = json.Unmarshal(rec.Body.Bytes(), &body)
	return rec.Code, body
}

func TestScanChangesRejectsUnknownQueryParam(t *testing.T) {
	rec := httptest.NewRecorder()
	NewScanChangesHandler(nil).List(rec, httptest.NewRequest(http.MethodGet, "/scans/x/changes?bogus=1", nil))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("want 401 before any other check, got %d", rec.Code)
	}
}

func TestScanChangesHandlerValidation(t *testing.T) {
	base := "/api/v1/scans/scan-20261016-190603/changes"

	if code, _ := scanGet(scanRouter(false), base); code != http.StatusUnauthorized {
		t.Errorf("no claims → %d, want 401", code)
	}

	h := scanRouter(true)
	cases := map[string]string{
		"/api/v1/scans/bad$scanid/changes": "INVALID_SCAN_ID",
		base + "?bogus=1":                  "INVALID_QUERY_PARAM",
		base + "?change_type=nope":         "INVALID_CHANGE_TYPE",
		base + "?entity_type=nope":         "INVALID_ENTITY_TYPE",
		base + "?limit=0":                  "INVALID_PAGINATION",
		base + "?limit=201":                "INVALID_PAGINATION",
		base + "?limit=abc":                "INVALID_PAGINATION",
		base + "?page=0":                   "INVALID_PAGINATION",
		base + "?page=abc":                 "INVALID_PAGINATION",
		base + "?page=100001&limit=200":    "INVALID_PAGINATION",
	}
	for path, want := range cases {
		code, body := scanGet(h, path)
		if code != http.StatusBadRequest || body["error"] != want {
			t.Errorf("%s → %d %v, want 400 %s", path, code, body, want)
		}
	}
}

func TestScanChangesPagingDefaultsAndBounds(t *testing.T) {
	rec := httptest.NewRecorder()
	page, limit, ok := ParseChangesPaging(rec, nil)
	if !ok || page != 1 || limit != 50 {
		t.Fatalf("defaults = page %d limit %d ok %v", page, limit, ok)
	}
	rec = httptest.NewRecorder()
	page, limit, ok = ParseChangesPaging(rec, map[string][]string{"page": {"7"}, "limit": {"200"}})
	if !ok || page != 7 || limit != 200 {
		t.Fatalf("parsed = page %d limit %d ok %v", page, limit, ok)
	}
	if rec.Code == http.StatusOK && rec.Body.Len() > 0 {
		t.Fatalf("valid values must not write a response")
	}
}

func TestParseChangeTypeAndEntityTypeNormalise(t *testing.T) {
	rec := httptest.NewRecorder()
	if got, ok := ParseChangeType(rec, "created"); !ok || got != "CREATED" {
		t.Fatalf("change_type = %q ok %v, want CREATED", got, ok)
	}
	rec = httptest.NewRecorder()
	if got, ok := ParseEntityType(rec, "Trust_Edge"); !ok || got != "trust_edge" {
		t.Fatalf("entity_type = %q ok %v, want trust_edge", got, ok)
	}
	rec = httptest.NewRecorder()
	if got, ok := ParseChangeType(rec, ""); !ok || got != "" {
		t.Fatalf("empty change_type = %q ok %v, want empty", got, ok)
	}
}

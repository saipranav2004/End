# Module template

Go ignores directories that start with `_`, so nothing here is compiled.

To add a new feature:

1. `cp -r internal/modules/_template internal/modules/<feature>` (lower-case, one word).
2. In each `.go.tmpl` file: rename it to `.go`, change `package example` to your package name,
   and rename `Example` to your feature.
3. Register the module in `cmd/api-server/main.go`:
   `Modules: []routes.Module{ ..., <feature>.New(resolver) }`
4. Add the new routes to `internal/routes/testdata/routes.golden`
   (`go test ./internal/routes -update`, then review the diff).
5. Add a request to `docs/postman`.

See `docs/ARCHITECTURE.md` for the rules.

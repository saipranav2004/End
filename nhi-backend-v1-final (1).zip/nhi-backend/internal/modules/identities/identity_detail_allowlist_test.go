package identities

import "testing"

func TestIdentityDetailAllowListRejectsEventsOnlyParams(t *testing.T) {
	// The identity detail endpoint must keep rejecting events-only parameters.
	for _, k := range []string{"section", "event_id", "action", "result", "source_ip", "read_write", "resource", "credential"} {
		if _, ok := identityDetailAllowed[k]; ok {
			t.Errorf("identityDetailAllowed unexpectedly accepts %q", k)
		}
	}
}

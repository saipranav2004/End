package filters

import (
	"log"
	"net/http"

	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/middleware"
)

type FilterHandler struct {
	filterService *FilterService
}

func NewFilterHandler(filterService *FilterService) *FilterHandler {
	return &FilterHandler{filterService: filterService}
}

func (h *FilterHandler) GetFilters(w http.ResponseWriter, r *http.Request) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		httpx.WriteJSON(w, http.StatusUnauthorized, httpx.APIResponse{
			Success: false,
			Message: "Unauthorized",
		})
		return
	}

	if httpx.RejectUnknownQuery(w, r, httpx.NoQuery) {
		return
	}

	filters, err := h.filterService.GetFilters(r.Context(), claims.UserID, claims.TenantID, claims.DBName)
	if err != nil {
		log.Printf("filter options failed: %v", err)
		httpx.WriteJSON(w, http.StatusInternalServerError, httpx.APIResponse{
			Success: false,
			Message: "Failed to retrieve filter options",
			Error:   "FILTERS_LOAD_FAILED",
		})
		return
	}

	httpx.WriteJSON(w, http.StatusOK, httpx.APIResponse{
		Success: true,
		Message: "Filter options retrieved successfully",
		Data:    filters,
	})
}

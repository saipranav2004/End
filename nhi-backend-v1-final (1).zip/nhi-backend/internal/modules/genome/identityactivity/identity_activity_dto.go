// Package identityactivity serves
// GET /api/v1/genome/identities/{source_type}/{identity_name}/activity: call
// volume and recent calls, read entirely from ClickHouse log_events.
package identityactivity

import "time"

// Response is the data block (the recent-calls page cursor travels in
// meta.next_cursor).
type Response struct {
	Volume      []VolumePoint `json:"volume"`
	RecentCalls []RecentCall  `json:"recent_calls"`
	TotalCalls  *uint64       `json:"total_calls"` // uniqExact(event_id) in the window; null when ClickHouse is unavailable
}

// VolumePoint is one call-volume bucket: "2026-10-01" for bucket=day,
// "2026-10-01T14:00:00Z" for bucket=hour.
type VolumePoint struct {
	Bucket string `json:"bucket"`
	Calls  uint64 `json:"calls"`
}

// RecentCall is one row of the recent-calls table.
type RecentCall struct {
	EventID    string    `json:"event_id"`
	EventTime  time.Time `json:"event_time"`
	APICall    string    `json:"api_call"` // event_source + ':' + event_name (".amazonaws.com" suffix removed)
	Resource   string    `json:"resource"` // first ARN of the split log_events.resource_arns ("" when the event has none)
	SourceIP   string    `json:"source_ip"`
	Region     string    `json:"region"`
	RiskStatus string    `json:"risk_status"`
	RiskScore  *uint8    `json:"risk_score"` // log_events.event_risk_score; null when the event has no numeric score
}

package identitytimeline

import (
	"context"
	"database/sql"
	"time"

	"nhi-backend-api/internal/modules/genome/common"
	"nhi-backend-api/internal/platform/scope"
)

// Repository reads the rows behind the identity timeline from the
// caller's tenant schema. The timeline is derived from current tables —
// alerts, baseline_versions and baselines — because the pipeline keeps no
// immutable event history. Read-only.
type Repository struct{}

// NewRepository creates the repository.
func NewRepository() *Repository { return &Repository{} }

// AlertRow is one alerts row of the identity (the "anomaly" item).
type AlertRow struct {
	ID        int64
	Key       common.MonitoringKey
	Dimension string
	Reason    string
	Status    string
	CreatedAt time.Time
}

// Alerts returns every alert stored under the keys (identity key and
// shared workload key), newest first.
func (r *Repository) Alerts(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) ([]AlertRow, error) {
	out := []AlertRow{}
	if len(keys) == 0 {
		return out, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT a.id, a.source_type, a.identity_name, a.dimension, a.reason, a.status, a.created_at
	      FROM ` + resolved.Table("alerts") + ` a` + common.KeyJoin("a") + `
	      ORDER BY a.created_at DESC, a.id DESC`
	rows, err := resolved.DB.QueryContext(ctx, q, types, names)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "timeline alerts", err)
	}
	defer rows.Close()
	for rows.Next() {
		var row AlertRow
		if err := rows.Scan(&row.ID, &row.Key.SourceType, &row.Key.IdentityName, &row.Dimension, &row.Reason, &row.Status, &row.CreatedAt); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "timeline alerts", err)
		}
		row.CreatedAt = row.CreatedAt.UTC()
		out = append(out, row)
	}
	return out, common.WrapMonitoringErr(ctx, "timeline alerts", rows.Err())
}

// BaselineMilestoneRow carries the two lifecycle timestamps of a baselines
// row: first_seen_date (learning started) and active_since (established).
type BaselineMilestoneRow struct {
	Key           common.MonitoringKey // the key the row is stored under (identity key or shared workload key)
	FirstSeenDate *time.Time           // DATE column, midnight UTC
	ActiveSince   *time.Time
}

// BaselineMilestones returns the baselines row of the identity, preferring
// the identity key over the shared workload key; nil when there is none.
func (r *Repository) BaselineMilestones(ctx context.Context, resolved *scope.DataScope, keys []common.MonitoringKey) (*BaselineMilestoneRow, error) {
	if len(keys) == 0 {
		return nil, nil
	}
	types, names := common.KeyArrays(keys)
	q := `SELECT b.source_type, b.identity_name, b.first_seen_date, b.active_since
	      FROM ` + resolved.Table("baselines") + ` b` + common.KeyPreferenceJoin("b") + `
	      ORDER BY k.preference
	      LIMIT 1`
	var (
		row       BaselineMilestoneRow
		firstSeen sql.NullTime
		active    sql.NullTime
	)
	err := resolved.DB.QueryRowContext(ctx, q, types, names).Scan(&row.Key.SourceType, &row.Key.IdentityName, &firstSeen, &active)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "baseline milestones", err)
	}
	if firstSeen.Valid {
		d := firstSeen.Time
		t := time.Date(d.Year(), d.Month(), d.Day(), 0, 0, 0, 0, time.UTC)
		row.FirstSeenDate = &t
	}
	if active.Valid {
		t := active.Time.UTC()
		row.ActiveSince = &t
	}
	return &row, nil
}

// PublishedVersionRow is one baseline_versions row (version, published_at).
type PublishedVersionRow struct {
	Key         common.MonitoringKey
	Version     int64
	PublishedAt time.Time
}

// PublishedVersions returns the version history stored under key, newest
// first.
func (r *Repository) PublishedVersions(ctx context.Context, resolved *scope.DataScope, key common.MonitoringKey) ([]PublishedVersionRow, error) {
	q := `SELECT v.source_type, v.identity_name, v.version, v.published_at
	      FROM ` + resolved.Table("baseline_versions") + ` v
	      WHERE v.source_type = $1 AND v.identity_name = $2
	      ORDER BY v.published_at DESC, v.version DESC`
	rows, err := resolved.DB.QueryContext(ctx, q, key.SourceType, key.IdentityName)
	if err != nil {
		return nil, common.WrapMonitoringErr(ctx, "published baseline versions", err)
	}
	defer rows.Close()
	out := []PublishedVersionRow{}
	for rows.Next() {
		var v PublishedVersionRow
		if err := rows.Scan(&v.Key.SourceType, &v.Key.IdentityName, &v.Version, &v.PublishedAt); err != nil {
			return nil, common.WrapMonitoringErr(ctx, "published baseline versions", err)
		}
		v.PublishedAt = v.PublishedAt.UTC()
		out = append(out, v)
	}
	return out, common.WrapMonitoringErr(ctx, "published baseline versions", rows.Err())
}

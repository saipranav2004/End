// Package identitysummary serves
// GET /api/v1/genome/identities/{source_type}/{identity_name}: the identity
// page header.
package identitysummary

import (
	"time"

	"nhi-backend-api/internal/modules/genome/common"
)

// Response is the data block.
type Response struct {
	Identity        Record               `json:"identity"`
	Risk            RiskSnapshot         `json:"risk"`
	BaselineSummary BaselineSummary      `json:"baseline_summary"`
	HeadlineMetrics HeadlineMetrics      `json:"headline_metrics"`
	Links           common.IdentityLinks `json:"links"`
}

// Record is the identity block, normalized from the latest snapshot of the
// tenant's identities table. Optional attributes are null when the
// discovery row does not carry them.
type Record struct {
	ID              string  `json:"id"`                // source_type + ':' + identity_name
	SourceType      string  `json:"source_type"`       // compact family, e.g. ECS
	NHIIdentityType string  `json:"nhi_identity_type"` // registry subtype, e.g. ecs_task
	IdentityName    string  `json:"identity_name"`     // canonical ARN or typed fallback key
	DisplayName     string  `json:"display_name"`
	WorkloadKey     string  `json:"workload_key"`
	Status          *string `json:"status"` // raw identities.status (lifecycle values NEED CONFIRMATION)
	AccountID       string  `json:"account_id"`
	Region          *string `json:"region"`
	ServiceName     *string `json:"service_name"`
	RoleType        *string `json:"role_type"`
	RoleARN         *string `json:"role_arn"`
}

// RiskSnapshot is the latest identity_risk_scores snapshot; all null when
// the identity has not been scored yet.
type RiskSnapshot struct {
	Score    *int    `json:"score"`
	Severity *string `json:"severity"`
	Status   *string `json:"status"` // identity_risk_scores.score_status
}

// BaselineSummary is from baselines; all null when no baseline row exists
// for the identity or its workload key.
type BaselineSummary struct {
	Status       *string `json:"status"`
	BuiltDays    *int    `json:"built_days"`
	RequiredDays *int    `json:"required_days"`
}

// HeadlineMetrics. CallsInWindow and LastSeen come from ClickHouse
// log_events and are null when it is not configured or unavailable;
// OpenAnomalies comes from alerts.
type HeadlineMetrics struct {
	CallsInWindow *uint64    `json:"calls_in_window"`
	OpenAnomalies *int       `json:"open_anomalies"`
	LastSeen      *time.Time `json:"last_seen"`
}

package identitylist

import (
	"net/http"
	"net/url"
	"nhi-backend-api/internal/modules/posture/common"
	"strings"
)

// IdentityFilterParams are the filter parameters shared by /identities,
// /identities/facets and /posture/export.
var IdentityFilterParams = []string{
	"window", "band", "severity", "category", "account", "type", "pillar", "failing_check", "changed", "q",
}

// ParseIdentityFilter validates the shared filter parameters. withSort adds
// sort, limit and cursor (list only). The caller has already run common.StrictQuery.
func ParseIdentityFilter(w http.ResponseWriter, q url.Values, withSort bool) (IdentityFilter, bool) {
	var f IdentityFilter
	var ok bool
	if f.Window, ok = common.QueryWindow(w, q); !ok {
		return f, false
	}
	if f.Bands, ok = common.CsvEnum(w, q, "band", common.Bands); !ok {
		return f, false
	}
	if f.Severities, ok = common.CsvEnum(w, q, "severity", common.Severities); !ok {
		return f, false
	}
	if f.Categories, ok = common.CsvValues(w, q, "category"); !ok {
		return f, false
	}
	if f.Accounts, ok = common.CsvValues(w, q, "account"); !ok {
		return f, false
	}
	if f.Types, ok = common.CsvValues(w, q, "type"); !ok {
		return f, false
	}
	for i := range f.Types {
		f.Types[i] = strings.ToUpper(f.Types[i])
	}
	if f.Pillars, ok = common.CsvValues(w, q, "pillar"); !ok {
		return f, false
	}
	for i, p := range f.Pillars {
		if !common.TokenRegex.MatchString(p) {
			common.Invalid(w, "pillar", "pillar is not valid")
			return f, false
		}
		f.Pillars[i] = strings.ToLower(p)
	}
	if f.FailingChecks, ok = common.CsvValues(w, q, "failing_check"); !ok {
		return f, false
	}
	for _, rule := range f.FailingChecks {
		if !common.RuleIDRegex.MatchString(rule) {
			common.Invalid(w, "failing_check", "failing_check is not valid")
			return f, false
		}
	}
	if raw := strings.ToLower(strings.TrimSpace(q.Get("changed"))); raw != "" {
		switch raw {
		case ChangedDown, ChangedUp, ChangedSame:
			f.Changed = raw
		default:
			common.Invalid(w, "changed", "changed must be down, up or same")
			return f, false
		}
	}
	if raw := strings.TrimSpace(q.Get("q")); raw != "" {
		if n := len([]rune(raw)); n < 2 || n > 100 {
			common.Invalid(w, "q", "q must be 2 to 100 characters")
			return f, false
		}
		f.Q = raw
	}
	f.Sort = SortScore
	if withSort {
		if raw := strings.TrimSpace(q.Get("sort")); raw != "" {
			valid := false
			for _, k := range SortKeys {
				if raw == k {
					valid, f.Sort = true, k
				}
			}
			if !valid {
				common.Invalid(w, "sort", "sort must be one of "+strings.Join(SortKeys, ", "))
				return f, false
			}
		}
		if f.Limit, ok = common.ParseLimit(w, q); !ok {
			return f, false
		}
		if f.Cursor, ok = common.ParseCursor(w, q); !ok {
			return f, false
		}
	}
	return f, true
}

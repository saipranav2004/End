package common

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"nhi-backend-api/internal/platform/middleware"
)

// Error codes of the documented error body.
const (
	codeInvalidParameter = "invalid_parameter"
	codeUnauthorized     = "unauthorized"
	codeForbidden        = "forbidden"
	codeNotFound         = "not_found"
	codeConflict         = "conflict"
	codeRateLimited      = "rate_limited"
	codeInternal         = "internal_error"
)

var (
	UuidRegex   = regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`)
	RuleIDRegex = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$`)
	TokenRegex  = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$`)
)

// ─────────────────────────────────────────────────────────────────────────
// Responses
// ─────────────────────────────────────────────────────────────────────────

func WriteJSON(w http.ResponseWriter, status int, v any) {
	body, err := json.Marshal(v)
	if err != nil {
		log.Printf("posture api: encode response: %v", err)
		status, body = http.StatusInternalServerError,
			[]byte(`{"error":{"code":"internal_error","message":"failed to encode response"}}`)
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_, _ = w.Write(body)
}

func writeError(w http.ResponseWriter, status int, code, message, field string) {
	WriteJSON(w, status, ErrorEnvelope{Error: ErrorBody{Code: code, Message: message, Field: field}})
}

func Invalid(w http.ResponseWriter, field, message string) {
	writeError(w, http.StatusBadRequest, codeInvalidParameter, message, field)
}

// Fail translates a service error into the documented error body.
func Fail(w http.ResponseWriter, what string, err error) {
	var pe *ParamError
	switch {
	case errors.As(err, &pe):
		Invalid(w, pe.Field, pe.Message)
	case errors.Is(err, ErrInvalidCursor):
		Invalid(w, "cursor", "cursor is not valid for this request")
	case errors.Is(err, ErrNotFound):
		writeError(w, http.StatusNotFound, codeNotFound, "not found", "")
	case errors.Is(err, ErrForbidden):
		writeError(w, http.StatusForbidden, codeForbidden, "your role may not perform this action", "")
	case errors.Is(err, ErrFindingResolved):
		writeError(w, http.StatusConflict, codeConflict, "the finding is resolved and can only be changed by the engine", "")
	case errors.Is(err, ErrConflict):
		writeError(w, http.StatusConflict, codeConflict, "the finding was changed by someone else; reload it and try again", "If-Match")
	default:
		log.Printf("posture api: %s failed: %v", what, err)
		writeError(w, http.StatusInternalServerError, codeInternal, "failed to "+what, "")
	}
}

// Respond writes a 200 envelope. With cache set it adds the scan-id ETag so
// the client can revalidate with If-None-Match.
func Respond(w http.ResponseWriter, env *Envelope, cache bool) {
	if cache {
		if tag := etagFor(env.Meta); tag != "" {
			w.Header().Set("ETag", tag)
		}
	}
	w.Header().Set("Cache-Control", "private, no-cache")
	WriteJSON(w, http.StatusOK, env)
}

// ─────────────────────────────────────────────────────────────────────────
// Caller, rate limit
// ─────────────────────────────────────────────────────────────────────────

// Begin authenticates the request and applies the per-tenant rate limit. It
// writes the error itself and returns ok=false when the request must stop.
func Begin(w http.ResponseWriter, r *http.Request) (Caller, bool) {
	claims := middleware.GetClaims(r)
	if claims == nil {
		writeError(w, http.StatusUnauthorized, codeUnauthorized, "missing or invalid token", "")
		return Caller{}, false
	}
	if ok, wait := tenantLimiter.Allow(claims.TenantID, time.Now()); !ok {
		secs := int(math.Ceil(wait.Seconds()))
		if secs < 1 {
			secs = 1
		}
		w.Header().Set("Retry-After", strconv.Itoa(secs))
		writeError(w, http.StatusTooManyRequests, codeRateLimited, "rate limit exceeded: 20 requests per second per tenant", "")
		return Caller{}, false
	}
	return Caller{UserID: claims.UserID, TenantID: claims.TenantID, DBName: claims.DBName, Role: claims.Role}, true
}

const (
	rateLimitPerSecond = 20.0
	rateLimitBurst     = 50.0
)

// limiter is a per-tenant token bucket.
type limiter struct {
	mu    sync.Mutex
	rate  float64
	burst float64
	m     map[string]*bucket
}

type bucket struct {
	tokens float64
	last   time.Time
}

func newLimiter(rate, burst float64) *limiter {
	return &limiter{rate: rate, burst: burst, m: map[string]*bucket{}}
}

var tenantLimiter = newLimiter(rateLimitPerSecond, rateLimitBurst)

// Allow takes one token for the key. When none is left it reports how long to
// wait for the next one.
func (l *limiter) Allow(key string, now time.Time) (bool, time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	b, ok := l.m[key]
	if !ok {
		if len(l.m) > 5000 { // drop idle tenants
			for k, v := range l.m {
				if now.Sub(v.last) > time.Minute {
					delete(l.m, k)
				}
			}
		}
		b = &bucket{tokens: l.burst, last: now}
		l.m[key] = b
	}
	b.tokens = math.Min(l.burst, b.tokens+now.Sub(b.last).Seconds()*l.rate)
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true, 0
	}
	return false, time.Duration((1 - b.tokens) / l.rate * float64(time.Second))
}

// ─────────────────────────────────────────────────────────────────────────
// Caching: ETag "<scan_id>"
// ─────────────────────────────────────────────────────────────────────────

func etagFor(m Meta) string {
	if m.ScanID == "" {
		return ""
	}
	return `"` + m.ScanID + `"`
}

// scanMetaFunc is the cheap "which scan is current" lookup every service has.
type scanMetaFunc func(ctx context.Context, c Caller) (Meta, error)

// NotModified answers 304 when If-None-Match carries the current scan's ETag.
// A failing lookup is ignored: the request simply proceeds uncached.
func NotModified(w http.ResponseWriter, r *http.Request, c Caller, scanMeta scanMetaFunc) bool {
	header := r.Header.Get("If-None-Match")
	if header == "" {
		return false
	}
	meta, err := scanMeta(r.Context(), c)
	if err != nil {
		return false
	}
	tag := etagFor(meta)
	if tag == "" {
		return false
	}
	for _, candidate := range strings.Split(header, ",") {
		candidate = strings.TrimPrefix(strings.TrimSpace(candidate), "W/")
		if candidate == "*" || candidate == tag {
			w.Header().Set("ETag", tag)
			w.Header().Set("Cache-Control", "private, no-cache")
			w.WriteHeader(http.StatusNotModified)
			return true
		}
	}
	return false
}

// ─────────────────────────────────────────────────────────────────────────
// Query parsing
// ─────────────────────────────────────────────────────────────────────────

// Allow builds a set of permitted query parameters.
func Allow(names ...string) map[string]struct{} {
	m := make(map[string]struct{}, len(names))
	for _, n := range names {
		m[n] = struct{}{}
	}
	return m
}

// StrictQuery rejects the first unknown parameter, so a typo is an error and
// not a silently ignored filter. It writes the 400 and returns false.
func StrictQuery(w http.ResponseWriter, q url.Values, allowed map[string]struct{}) bool {
	for k := range q {
		if _, ok := allowed[k]; !ok {
			names := make([]string, 0, len(allowed))
			for n := range allowed {
				names = append(names, n)
			}
			sort.Strings(names)
			list := "(none)"
			if len(names) > 0 {
				list = strings.Join(names, ", ")
			}
			Invalid(w, k, fmt.Sprintf("unknown query parameter %q; allowed: %s", k, list))
			return false
		}
	}
	return true
}

func QueryWindow(w http.ResponseWriter, q url.Values) (Window, bool) {
	win, ok := ParseWindow(q.Get("window"))
	if !ok {
		Invalid(w, "window", "window must be one of "+strings.Join(WindowLabels, ", "))
		return win, false
	}
	return win, true
}

// ParseLimit reads ?limit= (default 50). Values above 100 are clamped to 100.
func ParseLimit(w http.ResponseWriter, q url.Values) (int, bool) {
	raw := strings.TrimSpace(q.Get("limit"))
	if raw == "" {
		return 50, true
	}
	n, err := strconv.Atoi(raw)
	if err != nil || n < 1 {
		Invalid(w, "limit", "limit must be a positive integer (maximum 100)")
		return 0, false
	}
	if n > 100 {
		n = 100
	}
	return n, true
}

func ParseCursor(w http.ResponseWriter, q url.Values) (string, bool) {
	c := strings.TrimSpace(q.Get("cursor"))
	if len(c) > 1024 {
		Invalid(w, "cursor", "cursor is too long")
		return "", false
	}
	return c, true
}

const maxListValues = 50

// CsvValues splits a comma-separated parameter into trimmed, non-empty values.
func CsvValues(w http.ResponseWriter, q url.Values, name string) ([]string, bool) {
	raw := strings.TrimSpace(q.Get(name))
	if raw == "" {
		return nil, true
	}
	var out []string
	for _, p := range strings.Split(raw, ",") {
		if p = strings.TrimSpace(p); p != "" {
			if len(p) > 128 {
				Invalid(w, name, name+" contains a value that is too long")
				return nil, false
			}
			out = append(out, p)
		}
	}
	if len(out) > maxListValues {
		Invalid(w, name, fmt.Sprintf("%s accepts at most %d values", name, maxListValues))
		return nil, false
	}
	return out, true
}

// CsvEnum reads a comma-separated parameter whose values must match (case
// insensitively) one of the allowed spellings; the allowed spelling is returned.
func CsvEnum(w http.ResponseWriter, q url.Values, name string, allowed []string) ([]string, bool) {
	vals, ok := CsvValues(w, q, name)
	if !ok {
		return nil, false
	}
	out := make([]string, 0, len(vals))
	for _, v := range vals {
		match := ""
		for _, a := range allowed {
			if strings.EqualFold(a, v) {
				match = a
				break
			}
		}
		if match == "" {
			Invalid(w, name, fmt.Sprintf("%s %q is not valid; allowed: %s", name, v, strings.Join(allowed, ", ")))
			return nil, false
		}
		out = append(out, match)
	}
	return out, true
}

// pathID reads the {id} path variable as an identity UUID.
func IdentityIDOK(w http.ResponseWriter, id string) (string, bool) {
	id = strings.TrimSpace(id)
	if !UuidRegex.MatchString(id) {
		Invalid(w, "id", "id must be a valid identity UUID")
		return "", false
	}
	return strings.ToLower(id), true
}

func RuleIDOK(w http.ResponseWriter, id string) (string, bool) {
	id = strings.TrimSpace(id)
	if !RuleIDRegex.MatchString(id) {
		Invalid(w, "rule_id", "rule_id is not valid")
		return "", false
	}
	return id, true
}

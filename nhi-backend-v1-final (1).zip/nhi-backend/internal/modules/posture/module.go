// Package posture serves the ISPM posture dashboard API (ISPM_Dashboard_API_v2.md).
//
// Unlike the other modules, every endpoint here answers in the envelope the
// document defines: { data, page, meta } on success and
// { error: { code, message, field } } on failure. Common rules enforced for
// every endpoint: Bearer JWT (tenant from the token only), a 20 req/s per
// tenant limit with bursts up to 50, strict query validation, and
// ETag/If-None-Match keyed on the scan id.
//
// The package reads the precomputed ispm_* tables (the worker writes them after
// every scan). PATCH /findings/{id} is the one write.
package posture

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/identitygraph"
	"nhi-backend-api/internal/identitygraph/eventstore"
	"nhi-backend-api/internal/modules/posture/accessgraph"
	"nhi-backend-api/internal/modules/posture/checkdetail"
	"nhi-backend-api/internal/modules/posture/export"
	"nhi-backend-api/internal/modules/posture/facets"
	"nhi-backend-api/internal/modules/posture/findingupdate"
	"nhi-backend-api/internal/modules/posture/identityactivity"
	"nhi-backend-api/internal/modules/posture/identityalerts"
	"nhi-backend-api/internal/modules/posture/identitychecks"
	"nhi-backend-api/internal/modules/posture/identitycredentials"
	"nhi-backend-api/internal/modules/posture/identityheader"
	"nhi-backend-api/internal/modules/posture/identityhistory"
	"nhi-backend-api/internal/modules/posture/identitylist"
	"nhi-backend-api/internal/modules/posture/identityposture"
	"nhi-backend-api/internal/modules/posture/identityroleuse"
	"nhi-backend-api/internal/modules/posture/overview"
	"nhi-backend-api/internal/modules/posture/quickwins"
	"nhi-backend-api/internal/platform/middleware"
	"nhi-backend-api/internal/platform/scope"
)

// BasePath is where the posture API is mounted, below /api/v1 (and /api).
// /identities and /identities/{id} already belong to the identities module, so
// this API lives under its own prefix.
const BasePath = middleware.PostureBasePath

// Module wires the package's handlers and registers their routes.
type Module struct {
	overview            *overview.PostureOverviewHandler
	quickWinIdentities  *quickwins.QuickWinIdentitiesHandler
	export              *export.PostureExportHandler
	identitiesList      *identitylist.IdentitiesListHandler
	identitiesFacets    *facets.IdentitiesFacetsHandler
	identityHeader      *identityheader.IdentityHeaderHandler
	identityPosture     *identityposture.IdentityPostureHandler
	identityChecks      *identitychecks.IdentityChecksHandler
	identityHistory     *identityhistory.IdentityHistoryHandler
	identityCredentials *identitycredentials.IdentityCredentialsHandler
	identityRoleUse     *identityroleuse.IdentityRoleUseHandler
	identityActivity    *identityactivity.IdentityActivityHandler
	identityAlerts      *identityalerts.IdentityAlertsHandler
	identityGraph       *accessgraph.IdentityGraphHandler
	checkDetail         *checkdetail.CheckDetailHandler
	findingUpdate       *findingupdate.FindingUpdateHandler
}

// New builds the module. events may be nil: the activity endpoint then answers
// with meta.data_available = false.
func New(resolver *scope.Resolver, events *eventstore.Repository) *Module {
	return &Module{
		overview:            overview.NewPostureOverviewHandler(overview.NewPostureOverviewService(overview.NewPostureOverviewRepository(), resolver)),
		quickWinIdentities:  quickwins.NewQuickWinIdentitiesHandler(quickwins.NewQuickWinIdentitiesService(quickwins.NewQuickWinIdentitiesRepository(), resolver)),
		export:              export.NewPostureExportHandler(export.NewPostureExportService(export.NewPostureExportRepository(), resolver)),
		identitiesList:      identitylist.NewIdentitiesListHandler(identitylist.NewIdentitiesListService(identitylist.NewIdentitiesListRepository(), resolver)),
		identitiesFacets:    facets.NewIdentitiesFacetsHandler(facets.NewIdentitiesFacetsService(facets.NewIdentitiesFacetsRepository(), resolver)),
		identityHeader:      identityheader.NewIdentityHeaderHandler(identityheader.NewIdentityHeaderService(identityheader.NewIdentityHeaderRepository(), resolver)),
		identityPosture:     identityposture.NewIdentityPostureHandler(identityposture.NewIdentityPostureService(identityposture.NewIdentityPostureRepository(), resolver)),
		identityChecks:      identitychecks.NewIdentityChecksHandler(identitychecks.NewIdentityChecksService(identitychecks.NewIdentityChecksRepository(), resolver)),
		identityHistory:     identityhistory.NewIdentityHistoryHandler(identityhistory.NewIdentityHistoryService(identityhistory.NewIdentityHistoryRepository(), resolver)),
		identityCredentials: identitycredentials.NewIdentityCredentialsHandler(identitycredentials.NewIdentityCredentialsService(identitycredentials.NewIdentityCredentialsRepository(), resolver)),
		identityRoleUse:     identityroleuse.NewIdentityRoleUseHandler(identityroleuse.NewIdentityRoleUseService(identityroleuse.NewIdentityRoleUseRepository(), resolver)),
		identityActivity: identityactivity.NewIdentityActivityHandler(identityactivity.NewIdentityActivityService(
			identityactivity.NewIdentityActivityRepository(events, identitygraph.NewIdentityLookupRepository()), resolver)),
		identityAlerts: identityalerts.NewIdentityAlertsHandler(identityalerts.NewIdentityAlertsService(identityalerts.NewIdentityAlertsRepository(), resolver)),
		identityGraph:  accessgraph.NewIdentityGraphHandler(accessgraph.NewIdentityGraphService(accessgraph.NewIdentityGraphRepository(), resolver)),
		checkDetail:    checkdetail.NewCheckDetailHandler(checkdetail.NewCheckDetailService(checkdetail.NewCheckDetailRepository(), resolver)),
		findingUpdate:  findingupdate.NewFindingUpdateHandler(findingupdate.NewFindingUpdateService(findingupdate.NewFindingUpdateRepository(), resolver)),
	}
}

// Register mounts the 16 endpoints under BasePath. Static paths come before
// the {id} ones so /identities/facets is not read as an identity id.
func (m *Module) Register(r *mux.Router) {
	p := r.PathPrefix(BasePath).Subrouter()
	get := func(path string, h http.HandlerFunc) { p.HandleFunc(path, h).Methods(http.MethodGet) }

	get("/posture/overview", m.overview.Get)
	get("/posture/quick-wins/{rule_id}/identities", m.quickWinIdentities.Get)
	get("/posture/export", m.export.Get)
	get("/identities", m.identitiesList.List)
	get("/identities/facets", m.identitiesFacets.Get)
	get("/identities/{id}", m.identityHeader.Get)
	get("/identities/{id}/posture", m.identityPosture.Get)
	get("/identities/{id}/checks", m.identityChecks.Get)
	get("/identities/{id}/history", m.identityHistory.Get)
	get("/identities/{id}/credentials", m.identityCredentials.Get)
	get("/identities/{id}/role-use", m.identityRoleUse.Get)
	get("/identities/{id}/activity", m.identityActivity.Get)
	get("/identities/{id}/alerts", m.identityAlerts.Get)
	get("/identities/{id}/graph", m.identityGraph.Get)
	get("/checks/{rule_id}", m.checkDetail.Get)
	p.HandleFunc("/findings/{id}", m.findingUpdate.Patch).Methods(http.MethodPatch)
}

package routes

import (
	"net/http"

	"github.com/gorilla/mux"

	"nhi-backend-api/internal/modules/auth"
	"nhi-backend-api/internal/platform/httpx"
	"nhi-backend-api/internal/platform/middleware"
)

// Module is a self-contained feature that registers its own routes on an
// authenticated router (paths are relative to /api/v1).
type Module interface {
	Register(r *mux.Router)
}

type HandlerContainer struct {
	Auth *auth.Module

	// Modules are mounted on the authenticated /api/v1 router.
	Modules []Module
}

func SetupRoutes(h HandlerContainer) *mux.Router {
	r := mux.NewRouter()
	r.Use(middleware.RequestLogger)
	r.Use(middleware.Recoverer)

	r.NotFoundHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if middleware.IsPosturePath(req.URL.Path) {
			middleware.WritePostureError(w, http.StatusNotFound, "not_found", "route not found")
			return
		}
		httpx.WriteJSON(w, http.StatusNotFound, map[string]any{
			"success": false,
			"message": "route not found: " + req.Method + " " + req.URL.Path,
		})
	})
	r.MethodNotAllowedHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if middleware.IsPosturePath(req.URL.Path) {
			middleware.WritePostureError(w, http.StatusMethodNotAllowed, "method_not_allowed", "method not allowed")
			return
		}
		httpx.WriteJSON(w, http.StatusMethodNotAllowed, map[string]any{
			"success": false,
			"message": "method not allowed: " + req.Method + " " + req.URL.Path,
		})
	})

	r.HandleFunc("/health", func(w http.ResponseWriter, req *http.Request) {
		httpx.WriteJSON(w, http.StatusOK, map[string]string{"status": "healthy", "service": "nhi-backend-api"})
	}).Methods(http.MethodGet)

	if h.Auth == nil {
		return r
	}
	h.Auth.RegisterPublic(r)

	v1 := r.PathPrefix("/api/v1").Subrouter()
	v1.Use(h.Auth.Authenticate)
	h.Auth.Register(v1)
	for _, m := range h.Modules {
		m.Register(v1)
	}
	return r
}

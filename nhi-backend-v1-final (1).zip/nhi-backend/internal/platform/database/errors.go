package database

import (
	"errors"

	"github.com/jackc/pgx/v5/pgconn"
)

// IsUndefinedTable reports a missing relation (SQLSTATE 42P01). Optional
// sources (a table a tenant has not been migrated for yet) answer "no data
// yet" instead of failing when the table has not been created.
func IsUndefinedTable(err error) bool {
	var pe *pgconn.PgError
	return errors.As(err, &pe) && pe.Code == "42P01"
}

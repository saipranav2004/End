package httpx

import (
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"time"
)

// CheckUnknown returns the first query parameter that is not in allowed.
func CheckUnknown(q url.Values, allowed map[string]struct{}) (string, bool) {
	for k := range q {
		if _, ok := allowed[k]; !ok {
			return k, true
		}
	}
	return "", false
}

// AllowedList renders the allowed parameter names for error messages.
func AllowedList(allowed map[string]struct{}) string {
	if len(allowed) == 0 {
		return "(none)"
	}
	keys := make([]string, 0, len(allowed))
	for k := range allowed {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return strings.Join(keys, ", ")
}

// UnknownParamMessage is the standard 400 message for an unexpected parameter.
func UnknownParamMessage(unknown string, allowed map[string]struct{}) string {
	return fmt.Sprintf("Unknown query parameter: %s. Allowed parameters: %s", unknown, AllowedList(allowed))
}

// RejectUnknownQuery writes a 400 INVALID_QUERY_PARAM response and returns
// true when the request carries a parameter outside allowed.
func RejectUnknownQuery(w http.ResponseWriter, r *http.Request, allowed map[string]struct{}) bool {
	if unknown, ok := CheckUnknown(r.URL.Query(), allowed); ok {
		WriteError(w, http.StatusBadRequest, UnknownParamMessage(unknown, allowed), "INVALID_QUERY_PARAM")
		return true
	}
	return false
}

var dateLayouts = []string{
	"2006-01-02",
	time.RFC3339,
	"2006-01-02T15:04:05Z",
	"2006-01-02T15:04:05.000Z",
	"2006-01-02 15:04:05",
}

// IsValidDate reports whether s parses as a date or timestamp in any
// layout the API accepts.
func IsValidDate(s string) bool {
	s = strings.TrimSpace(s)
	if s == "" {
		return false
	}
	for _, l := range dateLayouts {
		if _, err := time.Parse(l, s); err == nil {
			return true
		}
	}
	return false
}

// NoQuery is the allow-list for endpoints that accept no query parameters.
var NoQuery = map[string]struct{}{}
